var _special_tile_8hpp =
[
    [ "SpecialTile", "class_special_tile.html", "class_special_tile" ],
    [ "SpecialType", "_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323", [
      [ "Start", "_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323aa6122a65eaa676f700ae68d393054a37", null ],
      [ "Event", "_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323aa4ecfc70574394990cf17bd83df499f7", null ],
      [ "Community", "_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323a7d61983c34edc2a8cabbea71c4732f62", null ],
      [ "Bahnhof", "_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323ae7296de46c78303787df1b1557dc80bf", null ],
      [ "Tax", "_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323a4b78ac8eb158840e9638a3aeb26c4a9d", null ],
      [ "LuxuryTax", "_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323a79455282a6fd73c7388f940a4f74991b", null ],
      [ "Jail", "_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323a65f026d43888829dd504854e1b439194", null ],
      [ "GoToJail", "_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323adb3ebfa6ce280677097e365774609395", null ],
      [ "FreeParking", "_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323ab7765593ec829ba1c606ba287af8767a", null ],
      [ "Hubschrauberlandeplatz", "_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323aae43df0283be6d82f24f22e5979fb53b", null ]
    ] ]
];