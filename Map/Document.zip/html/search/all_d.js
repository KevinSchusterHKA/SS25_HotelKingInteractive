var searchData=
[
  ['name_0',['name',['../class_tile.html#aa5408d0f0f4a60f25796f651db2f84ac',1,'Tile']]],
  ['nodenames_1',['nodeNames',['../class_graph.html#affcb9c5aaa4ad77d3ff29876882fcaa0',1,'Graph']]]
];
