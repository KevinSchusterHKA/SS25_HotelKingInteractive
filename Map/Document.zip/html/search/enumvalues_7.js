var searchData=
[
  ['luxurytax_0',['LuxuryTax',['../_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323a79455282a6fd73c7388f940a4f74991b',1,'SpecialTile.hpp']]]
];
