var searchData=
[
  ['gotojail_0',['GoToJail',['../_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323adb3ebfa6ce280677097e365774609395',1,'SpecialTile.hpp']]]
];
