var indexSectionsWithContent =
{
  0: "abcdefghijklmnoprstuwz~",
  1: "gpst",
  2: "gmpst",
  3: "cdghmprst~",
  4: "afginpt",
  5: "ps",
  6: "bcefghjlstu",
  7: "abdefghklmorstwz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

