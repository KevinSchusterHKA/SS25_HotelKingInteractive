var searchData=
[
  ['tax_0',['Tax',['../_special_tile_8hpp.html#a3879bd0aba9f20985139f480b9f73323a4b78ac8eb158840e9638a3aeb26c4a9d',1,'SpecialTile.hpp']]]
];
