var searchData=
[
  ['setowner_0',['setOwner',['../class_property_tile.html#a884168b57086d083aa9b0aaef3b3f039',1,'PropertyTile']]],
  ['setrentlevels_1',['setRentLevels',['../class_property_tile.html#a873c3d520bf0881f79c40cdeec377f9d',1,'PropertyTile']]],
  ['specialtile_2',['SpecialTile',['../class_special_tile.html#a9bd763fe1a75d4da99dfa58ee485c810',1,'SpecialTile']]]
];
