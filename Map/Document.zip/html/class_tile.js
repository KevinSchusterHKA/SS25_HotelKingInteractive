var class_tile =
[
    [ "Tile", "class_tile.html#a49cd5dc5215809255a4b6e05fa3e08b4", null ],
    [ "~Tile", "class_tile.html#aecd90209e168f26bcdf36c2e445f424a", null ],
    [ "displayInfo", "class_tile.html#a6b4a178138fdfc16cbf8e4e3bb56b71d", null ],
    [ "getId", "class_tile.html#ac382874a902694c3ce05c84b5d0f6731", null ],
    [ "getName", "class_tile.html#a303e020a835786b276540615a2e5c4eb", null ],
    [ "getTypeString", "class_tile.html#a4e61d4b1c4e8aa821888fa18c001f343", null ],
    [ "id", "class_tile.html#a32d00999ec6ae098a2db62bf4c2c5e7c", null ],
    [ "name", "class_tile.html#aa5408d0f0f4a60f25796f651db2f84ac", null ]
];