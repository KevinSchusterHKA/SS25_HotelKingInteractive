var class_special_tile =
[
    [ "SpecialTile", "class_special_tile.html#a9bd763fe1a75d4da99dfa58ee485c810", null ],
    [ "displayInfo", "class_special_tile.html#af3c96d55aad00ea3ac2cfef303b30e4a", null ],
    [ "getSpecialType", "class_special_tile.html#a2d44fd9af4df5bbc3122406662c0f219", null ],
    [ "getTypeString", "class_special_tile.html#ab8fbfa5d583a390f3fd666e8e92753bd", null ]
];